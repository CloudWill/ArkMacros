/**
 * This is a stub file used by Jest for ignored filetypes.
 * Essentially, this tells them that the module does not export anything, so
 * there is nothing for it to type check.
 */
module.exports = {};
